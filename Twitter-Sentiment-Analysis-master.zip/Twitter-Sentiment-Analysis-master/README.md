# Twitter-Sentiment-Analysis


Naive Bayes Classifier implemented using Python-NLTK and Tweepy API. Goal is to classify twitter user tweets to generate an Optimist/Pessimist rating for a given user. Still working on a web app visualization. 
Includes tweet proceessing script for collecting and generating interesting user data.


(http://www.mtzmonica.com/)
